﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OUR_LogicSimulator.FrontEnd
{
    public partial class Gate_front : OurUserControl
    {
        #region constructor
        public Gate_front(string gateType)
        {
            InitializeComponent();
            this.gateType = gateType;
        }
        #endregion

        #region Private Attributes
        private string gateType = null;
        #endregion

        #region Event Handlers

        private void createGateDueToType(object sender, PaintEventArgs e)
        {

            //switch can be replaced by a one line of code using runtime Creation ((gotta GOOGLE it))
            Gate g;
            switch (gateType)
            {
                case "OR":
                    g = new OR();
                    break;
                case "NOT":
                    g = new NOT();
                    break;
                case "AND":
                    g = new AND();
                    break;
                case "NAND":
                    g = new NAND();
                    break;

                default:
                    g = null;
                    break;
            }
            g.Draw(sender, e);

        }

        #endregion

        private void rectangleShape2_Click(object sender, EventArgs e)
        {

        }

        private void rectangleShape1_Click(object sender, EventArgs e)
        {

        }

        private void rectangleShape1_MouseDown(object sender, MouseEventArgs e)
        {
            //rectangleShape1.FillColor = Color.SpringGreen;
            //rectangleShape1.FillGradientColor = Color.MediumSpringGreen;
        }

        public event EventHandler ButtonClick;

        protected void rectangleShape3_Click(object sender, EventArgs e)
        {
            //bubble the event up to the parent
            if (this.ButtonClick != null)
                this.ButtonClick(this, e);
        }
    }
}
