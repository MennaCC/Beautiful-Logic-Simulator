﻿using System;

namespace Decent_Custom_Logic_Simulator
{
    partial class Form1
    {
            /// <summary>
            /// Required designer variable.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary>
            /// Clean up any resources being used.
            /// </summary>
            /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

            #region Windows Form Designer generated code

            /// <summary>
            /// Required method for Designer support - do not modify
            /// the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSaveButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripOpenButton = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textBoxLocation = new System.Windows.Forms.TextBox();
            this.textBoxLocationEnd = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.node_Front1 = new Decent_Custom_Logic_Simulator.FrontEnd.Node_Front();
            this.input_Front1 = new Decent_Custom_Logic_Simulator.FrontEnd.Input_Front();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.AND = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.NAND = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.OR = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.NOR = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.XOR = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.XNOR = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.NOT = new Decent_Custom_Logic_Simulator.FrontEnd.customControl();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.input_Front2 = new Decent_Custom_Logic_Simulator.FrontEnd.Input_Front();
            this.node_Front2 = new Decent_Custom_Logic_Simulator.FrontEnd.Node_Front();
            this.node_Front3 = new Decent_Custom_Logic_Simulator.FrontEnd.Node_Front();
            this.toolStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.input_Front2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Black;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSaveButton,
            this.toolStripOpenButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(809, 25);
            this.toolStrip1.TabIndex = 6;
            this.toolStrip1.Text = "Menu";
            // 
            // toolStripSaveButton
            // 
            this.toolStripSaveButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSaveButton.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSaveButton.Image")));
            this.toolStripSaveButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSaveButton.Name = "toolStripSaveButton";
            this.toolStripSaveButton.Size = new System.Drawing.Size(23, 22);
            this.toolStripSaveButton.Text = "Save";
            this.toolStripSaveButton.Click += new System.EventHandler(this.toolStripSaveButton_Click);
            // 
            // toolStripOpenButton
            // 
            this.toolStripOpenButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripOpenButton.Image = ((System.Drawing.Image)(resources.GetObject("toolStripOpenButton.Image")));
            this.toolStripOpenButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripOpenButton.Name = "toolStripOpenButton";
            this.toolStripOpenButton.Size = new System.Drawing.Size(23, 22);
            this.toolStripOpenButton.Text = "Open";
            this.toolStripOpenButton.Click += new System.EventHandler(this.toolStripOpenButton_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textBoxLocation
            // 
            this.textBoxLocation.Location = new System.Drawing.Point(450, 375);
            this.textBoxLocation.Name = "textBoxLocation";
            this.textBoxLocation.Size = new System.Drawing.Size(100, 20);
            this.textBoxLocation.TabIndex = 11;
            this.textBoxLocation.TextChanged += new System.EventHandler(this.textBoxLocation_TextChanged);
            // 
            // textBoxLocationEnd
            // 
            this.textBoxLocationEnd.Location = new System.Drawing.Point(556, 375);
            this.textBoxLocationEnd.Name = "textBoxLocationEnd";
            this.textBoxLocationEnd.Size = new System.Drawing.Size(100, 20);
            this.textBoxLocationEnd.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.node_Front3);
            this.panel2.Controls.Add(this.input_Front2);
            this.panel2.Controls.Add(this.node_Front1);
            this.panel2.Controls.Add(this.input_Front1);
            this.panel2.Controls.Add(this.textBoxLocation);
            this.panel2.Controls.Add(this.textBoxLocationEnd);
            this.panel2.Location = new System.Drawing.Point(138, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(665, 402);
            this.panel2.TabIndex = 15;
            // 
            // node_Front1
            // 
            this.node_Front1.BackColor = System.Drawing.Color.Crimson;
            this.node_Front1.Location = new System.Drawing.Point(227, 156);
            this.node_Front1.Name = "node_Front1";
            this.node_Front1.Size = new System.Drawing.Size(10, 10);
            this.node_Front1.TabIndex = 14;
            // 
            // input_Front1
            // 
            this.input_Front1.BackColor = System.Drawing.Color.Snow;
            this.input_Front1.Location = new System.Drawing.Point(278, 141);
            this.input_Front1.Name = "input_Front1";
            this.input_Front1.Size = new System.Drawing.Size(120, 120);
            this.input_Front1.TabIndex = 13;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.Controls.Add(this.AND);
            this.flowLayoutPanel1.Controls.Add(this.NAND);
            this.flowLayoutPanel1.Controls.Add(this.OR);
            this.flowLayoutPanel1.Controls.Add(this.NOR);
            this.flowLayoutPanel1.Controls.Add(this.XOR);
            this.flowLayoutPanel1.Controls.Add(this.XNOR);
            this.flowLayoutPanel1.Controls.Add(this.NOT);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 28);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(120, 402);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // AND
            // 
            this.AND.BackColor = System.Drawing.Color.AliceBlue;
            this.AND.Location = new System.Drawing.Point(3, 3);
            this.AND.Name = "AND";
            this.AND.Size = new System.Drawing.Size(50, 79);
            this.AND.TabIndex = 0;
            this.AND.Text = "AND";
            this.AND.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlAND_Paint);
            this.AND.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // NAND
            // 
            this.NAND.BackColor = System.Drawing.Color.AliceBlue;
            this.NAND.Location = new System.Drawing.Point(59, 3);
            this.NAND.Name = "NAND";
            this.NAND.Size = new System.Drawing.Size(50, 79);
            this.NAND.TabIndex = 1;
            this.NAND.Text = "NAND";
            this.NAND.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlNAND_Paint);
            this.NAND.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // OR
            // 
            this.OR.BackColor = System.Drawing.Color.AliceBlue;
            this.OR.Location = new System.Drawing.Point(3, 88);
            this.OR.Name = "OR";
            this.OR.Size = new System.Drawing.Size(50, 79);
            this.OR.TabIndex = 6;
            this.OR.Text = "OR";
            this.OR.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlOR_Paint);
            this.OR.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // NOR
            // 
            this.NOR.BackColor = System.Drawing.Color.AliceBlue;
            this.NOR.Location = new System.Drawing.Point(59, 88);
            this.NOR.Name = "NOR";
            this.NOR.Size = new System.Drawing.Size(50, 79);
            this.NOR.TabIndex = 5;
            this.NOR.Text = "NOR";
            this.NOR.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlNOR_Paint);
            this.NOR.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // XOR
            // 
            this.XOR.BackColor = System.Drawing.Color.AliceBlue;
            this.XOR.Location = new System.Drawing.Point(3, 173);
            this.XOR.Name = "XOR";
            this.XOR.Size = new System.Drawing.Size(50, 79);
            this.XOR.TabIndex = 4;
            this.XOR.Text = "XOR";
            this.XOR.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlXOR_Paint);
            this.XOR.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // XNOR
            // 
            this.XNOR.BackColor = System.Drawing.Color.AliceBlue;
            this.XNOR.Location = new System.Drawing.Point(59, 173);
            this.XNOR.Name = "XNOR";
            this.XNOR.Size = new System.Drawing.Size(50, 79);
            this.XNOR.TabIndex = 3;
            this.XNOR.Text = "XNOR";
            this.XNOR.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlXNOR_Paint);
            this.XNOR.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // NOT
            // 
            this.NOT.BackColor = System.Drawing.Color.AliceBlue;
            this.NOT.Location = new System.Drawing.Point(3, 258);
            this.NOT.Name = "NOT";
            this.NOT.Size = new System.Drawing.Size(50, 79);
            this.NOT.TabIndex = 2;
            this.NOT.Text = "NOT";
            this.NOT.Paint += new System.Windows.Forms.PaintEventHandler(this.customControlNOT_Paint);
            this.NOT.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Gate_MouseDown);
            // 
            // input_Front2
            // 
            this.input_Front2.BackColor = System.Drawing.Color.Snow;
            this.input_Front2.Controls.Add(this.node_Front2);
            this.input_Front2.Location = new System.Drawing.Point(356, -39);
            this.input_Front2.Name = "input_Front2";
            this.input_Front2.Size = new System.Drawing.Size(120, 120);
            this.input_Front2.TabIndex = 15;
            // 
            // node_Front2
            // 
            this.node_Front2.BackColor = System.Drawing.Color.Crimson;
            this.node_Front2.Location = new System.Drawing.Point(0, 0);
            this.node_Front2.Name = "node_Front2";
            this.node_Front2.Size = new System.Drawing.Size(10, 10);
            this.node_Front2.TabIndex = 1;
            // 
            // node_Front3
            // 
            this.node_Front3.BackColor = System.Drawing.Color.Crimson;
            this.node_Front3.Location = new System.Drawing.Point(208, 105);
            this.node_Front3.Name = "node_Front3";
            this.node_Front3.Size = new System.Drawing.Size(10, 10);
            this.node_Front3.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(809, 436);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.toolStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = " ";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.input_Front2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

            }
            private System.Windows.Forms.ToolStrip toolStrip1;
            #endregion

            private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
            public System.Windows.Forms.TextBox textBoxLocation;
            public System.Windows.Forms.TextBox textBoxLocationEnd;
            private System.Windows.Forms.Panel panel2;
            private FrontEnd.customControl OR;
            private FrontEnd.customControl NOR;
            private FrontEnd.customControl XOR;
            private FrontEnd.customControl XNOR;
            private FrontEnd.customControl NOT;
            private FrontEnd.customControl NAND;
            private FrontEnd.customControl AND;
            private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
            private System.Windows.Forms.SaveFileDialog saveFileDialog1;
            private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripButton toolStripSaveButton;
        private System.Windows.Forms.ToolStripButton toolStripOpenButton;
        private FrontEnd.Input_Front input_Front1;
        private FrontEnd.Node_Front node_Front1;
        private FrontEnd.Node_Front node_Front3;
        private FrontEnd.Input_Front input_Front2;
        private FrontEnd.Node_Front node_Front2;
    }
    }

