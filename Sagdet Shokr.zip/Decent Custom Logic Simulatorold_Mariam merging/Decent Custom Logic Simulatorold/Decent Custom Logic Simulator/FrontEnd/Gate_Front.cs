﻿using OUR_LogicSimulator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decent_Custom_Logic_Simulator.FrontEnd
{
    public partial class Gate_Front : customControl
    {
        public Gate_Front()
        {
            InitializeComponent();
        }
        public Gate_Front(string gateType)
        {
            InitializeComponent();
            this.gateType = gateType;
        }

        #region Private Attributes

        private Point mol;
        private string gateType = null;

        #endregion

        protected override void OnPaint(PaintEventArgs pe)
        {
            createGateDueToType(pe);
            base.OnPaint(pe);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        /// <summary>
        /// el function d el mafrood an2elha fel base class w hya elly bt3mel el instantiation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void OurUserControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                this.Left = e.X + this.Left - mol.X;
                this.Top = e.Y + this.Top - mol.Y;

            }
        }

        private void createGateDueToType(PaintEventArgs e)
        {

            //switch can be replaced by a one line of code using runtime Creation ((gotta GOOGLE it))
            Gate g;
            switch (gateType)
            {
                case "OR":
                    g = new OR();
                    break;
                case "NOT":
                    g = new NOT();
                    break;
                case "AND":
                    g = new AND();
                    break;
                case "NAND":
                    g = new NAND();
                    break;
                case "NOR":
                    g = new NOR();
                    break;
                case "XOR":
                    g = new XOR();
                    break;
                case "XNOR":
                    g = new XNOR();
                    break;
                   
                default:
                    g = null;
                    break;
            }
            g.Draw(e);

        }
    }
}
